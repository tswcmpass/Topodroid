package com.topodroid.dev.distox_ble;

import android.content.Context;
import android.os.Handler;

import com.topodroid.TDX.TopoDroidApp;
import com.topodroid.dev.Device;
import com.topodroid.dev.TopoDroidProtocol;

public class DistoXBLEProtocol extends TopoDroidProtocol
{

    private final DistoXBLEComm mComm;
    private final Handler mLister;

    public static final int PACKET_INFO_FIRMWARE = 1;
    public static final int PACKET_INFO_HARDWARE = 2;
    public static final int PACKET_INFO_SHOTDATA = 3;
    public static final int PACKET_INFO_CALIDATA = 4;
    public static final int PACKET_INFO_ERR      = 5;

    public String mFirmVer;
    public String mHardVer;

    public DistoXBLEProtocol(Context ctx, TopoDroidApp app, Handler lister, Device device, DistoXBLEComm comm )
    {
        super( device, ctx );
        mLister = lister;
        mComm   = comm;
    }

    public int packetProcess(byte[] databuf)
    {
        if(databuf.length == 8)
        {
            if(databuf[0] != 0x38) return PACKET_INFO_ERR;
            int addr = (databuf[2] << 8 | databuf[1]) & 0xFFFF;
            if(addr == 0xE000)
            {
                mFirmVer = Integer.toString(databuf[3]) + "." + Integer.toString(databuf[4]);
                return PACKET_INFO_FIRMWARE;
            }
            else if(addr == 0xE004) {
                float HardVer = ((float)databuf[3]) / 10;
                mHardVer = Float.toString(HardVer);
                return PACKET_INFO_HARDWARE;
            }
            else return PACKET_INFO_ERR;


        }
        else if(databuf.length == 16)        //shot data
        {



        }

        return PACKET_INFO_ERR;
    }
}
