package com.topodroid.dev.distox_ble;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.content.Context;
import android.os.Handler;

import com.topodroid.TDX.R;
import com.topodroid.TDX.TDInstance;
import com.topodroid.TDX.TDToast;
import com.topodroid.TDX.TopoDroidApp;
import com.topodroid.dev.ConnectionState;
import com.topodroid.dev.DataType;
import com.topodroid.dev.Device;
import com.topodroid.dev.TopoDroidComm;
import com.topodroid.dev.ble.BleCallback;
import com.topodroid.dev.ble.BleComm;
import com.topodroid.dev.ble.BleOpChrtWrite;
import com.topodroid.dev.ble.BleOpConnect;
import com.topodroid.dev.ble.BleOpDisconnect;
import com.topodroid.dev.ble.BleOpNotify;
import com.topodroid.dev.ble.BleOperation;
import com.topodroid.dev.ble.BleUtils;
import com.topodroid.dev.bric.BricInfoDialog;
import com.topodroid.dev.bric.BricProto;
import com.topodroid.prefs.TDSetting;
import com.topodroid.utils.TDLog;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

public class DistoXBLEComm extends TopoDroidComm
        implements BleComm
{
    private ConcurrentLinkedQueue< BleOperation > mOps;
    private Context mContext;
    BleCallback mCallback;
    private String          mRemoteAddress;
    private BluetoothDevice mRemoteBtDevice;
    private DistoXBLEInfoDialog mDistoXBLEInfoDialog = null;

    BluetoothGattCharacteristic mReadChrt  = null;
    BluetoothGattCharacteristic mWriteChrt = null;
    //private boolean mReadInitialized  = false;
    //private boolean mWriteInitialized = false;
    private boolean mReconnect = false;

    private int mDataType;



    public DistoXBLEComm(Context ctx,TopoDroidApp app, String address, BluetoothDevice bt_device )
    {
        super( app );
        mRemoteAddress = address;
        mRemoteBtDevice  = bt_device;
        mContext = ctx;
        // TDLog.v( "SAP comm: cstr, addr " + address );
        //mOps = new ConcurrentLinkedQueue<BleOperation>();
        //clearPending();
    }

    // -------------------------------------------------------------
    /**
     * connection and data handling must run on a separate thread
     */

    // Device has mAddress, mModel, mName, mNickname, mType
    // the only thing that coincide with the remote_device is the address
    //
    private boolean connectDistoXBLEDevice( Device device, Handler lister, int data_type ) // FIXME BLEX_DATA_TYPE
    {
        if ( mRemoteBtDevice == null ) {
            TDToast.makeBad( R.string.ble_no_remote );
            // TDLog.Error("BRIC comm ERROR null remote device");
            // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** connect Device: null = [3b] status DISCONNECTED" );
            notifyStatus( ConnectionState.CONN_DISCONNECTED );
            return false;
        }
        notifyStatus( ConnectionState.CONN_WAITING );
        mReconnect   = true;
        mOps         = new ConcurrentLinkedQueue< BleOperation >();
        mProtocol    = new DistoXBLEProtocol( mContext, mApp, lister, device, this );
        // mChrtChanged = new BricChrtChanged( this, mQueue );
        // mCallback    = new BleCallback( this, mChrtChanged, false ); // auto_connect false
        mCallback    = new BleCallback( this, false ); // auto_connect false

        // mPendingCommands = 0; // FIXME COMPOSITE_COMMANDS
        // clearPending();

        TDLog.v( "DistoX-BLE comm ***** connect Device = [3a] status WAITING" );
        int ret = enqueueOp( new BleOpConnect( mContext, this, mRemoteBtDevice ) ); // exec connectGatt()
        TDLog.v( "DistoX-BLE connects ... " + ret);
        clearPending();
        return true;
    }

    public void connectGatt( Context ctx, BluetoothDevice bt_device ) // called from BleOpConnect
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** connect GATT");
        mContext = ctx;
        mCallback.connectGatt( mContext, bt_device );
        // setupNotifications(); // FIXME_BRIC
    }

    @Override
    public boolean connectDevice(String address, Handler /* ILister */ lister, int data_type )
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** connect Device");
        mNrPacketsRead = 0;
        mDataType      = data_type;
        return connectDistoXBLEDevice( TDInstance.getDeviceA(), lister, data_type );
    }
    // ----------------- DISCONNECT -------------------------------

    // from onConnectionStateChange STATE_DISCONNECTED
    public void disconnected()
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** disconnected" );
        TDLog.v( "DISTOX-BLE comm ***** disconnected" );
        clearPending();
        mOps.clear();
        // mPendingCommands = 0; // FIXME COMPOSITE_COMMANDS
        mBTConnected = false;
        notifyStatus( ConnectionState.CONN_DISCONNECTED );
    }

    public void connected()
    {
        clearPending();
    }

    public void disconnectGatt()  // called from BleOpDisconnect
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** disconnect GATT" );
        notifyStatus( ConnectionState.CONN_DISCONNECTED );
        mCallback.closeGatt();
    }

    @Override
    public boolean disconnectDevice()
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** disconnect device = connected:" + mBTConnected );
        return closeDevice();
    }

    // this is called only on a GATT failure, or the user disconnects
    private boolean closeDevice()
    {
        mReconnect = false;
        if ( mBTConnected ) {
            mBTConnected = false;
            notifyStatus( ConnectionState.CONN_DISCONNECTED ); // not necessary
            // TDLog.Log( TDLog.LOG_COMM, "BRIC comm ***** close device");
            int ret = enqueueOp( new BleOpDisconnect( mContext, this ) ); // exec disconnectGatt
            doNextOp();
            TDLog.v( "DISTOX-BLE comm: close Device - disconnect ... ops " + ret );
        }
        return true;
    }

    // --------------------------------------------------------------------------
    private BleOperation mPendingOp = null;

    private void clearPending()
    {
        mPendingOp = null;
        // if ( ! mOps.isEmpty() || mPendingCommands > 0 ) doNextOp();
        if ( ! mOps.isEmpty() ) doNextOp();
    }

    // @return the length of the ops queue
    private int enqueueOp( BleOperation op )
    {
        mOps.add( op );
        // printOps(); // DEBUG
        return mOps.size();
    }

    // access by BricChrtChanged
    private void doNextOp()
    {
        if ( mPendingOp != null ) {
            // TDLog.v( "BRIC comm: next op with pending not null, ops " + mOps.size() );
            return;
        }
        mPendingOp = mOps.poll();
        // TDLog.v( "BRIC comm: polled, ops " + mOps.size() );
        if ( mPendingOp != null ) {
            mPendingOp.execute();
        }
        // else if ( mPendingCommands > 0 ) {
        //   enqueueShot( this );
        //   -- mPendingCommands;
        // }
    }

    // BleComm interface

    public void changedMtu( int mtu ) {
        clearPending();
    }

    public void readedRemoteRssi( int rssi ) {
        clearPending();
    }

    public void changedChrt( BluetoothGattCharacteristic chrt )
    {
        // TDLog.v( "SAP comm: changedChrt" );
        String uuid_str = chrt.getUuid().toString();
        if ( uuid_str.equals( DistoXBLEConst.DISTOXBLE_CHRT_READ_UUID_STR ) ) {
            int res = ((DistoXBLEProtocol)mProtocol).packetProcess(chrt.getValue());
            if(res == DistoXBLEProtocol.PACKET_INFO_FIRMWARE)
            {
                if(mDistoXBLEInfoDialog != null) mDistoXBLEInfoDialog.SetVal(res,((DistoXBLEProtocol)mProtocol).mFirmVer);
            }
            else if(res == DistoXBLEProtocol.PACKET_INFO_HARDWARE)
            {
                if(mDistoXBLEInfoDialog != null) mDistoXBLEInfoDialog.SetVal(res,((DistoXBLEProtocol)mProtocol).mHardVer);
            }
        } else if ( uuid_str.equals( DistoXBLEConst.DISTOXBLE_CHRT_WRITE_UUID_STR ) ) {
            return;
        }
    }

    public void readedChrt( String uuid_str, byte[] bytes )
    {
        // TDLog.v( "SAP comm: readedChrt" );
    }

    public void writtenChrt( String uuid_str, byte[] bytes )
    {
        clearPending();
    }

    public void readedDesc( String uuid_str, String uuid_chrt_str, byte[] bytes )
    {
        TDLog.v( "DISTOXBLE comm: readedDesc" );
    }
    public void writtenDesc( String uuid_str, String uuid_chrt_str, byte[] bytes )
    {
        // TDLog.v( "SAP comm: ====== written desc " + uuid_str + " " + uuid_chrt_str );
        clearPending();
    }

    public void completedReliableWrite()
    {
        TDLog.v( "DistoXBLE comm: reliable write" );
    }

    /** read a characteristics
     * @param srvUuid  service UUID
     * @param chrtUuid characteristics UUID
     * @return true if successful
     * @note this is run by BleOpChrtRead
     */
    public boolean readChrt(UUID srvUuid, UUID chrtUuid )
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm: read chrt " + chrtUuid.toString() );
        return mCallback.readChrt( srvUuid, chrtUuid );
    }

    /** write a characteristics
     * @param srvUuid  service UUID
     * @param chrtUuid characteristics UUID
     * @return true if successful
     * @note this is run by BleOpChrtWrite
     */
    public boolean writeChrt( UUID srvUuid, UUID chrtUuid, byte[] bytes )
    {
        // TDLog.Log( TDLog.LOG_COMM, "BRIC comm: write chrt " + chrtUuid.toString() );
        return mCallback.writeChrt( srvUuid, chrtUuid, bytes );
    }

    /** react to service discovery
     * @param gatt   bluetooth GATT
     * @note from onServicesDiscovered
     */
    public int servicesDiscovered( BluetoothGatt gatt )
    {
        enqueueOp( new BleOpNotify( mContext, this, DistoXBLEConst.DISTOXBLE_SERVICE_UUID, DistoXBLEConst.DISTOXBLE_CHRT_READ_UUID, true ) );
        doNextOp();

        mBTConnected = true;
        TDLog.v( "DISTOX-BLE comm discovered services status CONNECTED" );
        notifyStatus( ConnectionState.CONN_CONNECTED );

        return 0;
    }

    public boolean enablePNotify( UUID srvUuid, UUID chrtUuid ) { return mCallback.enablePNotify( srvUuid, chrtUuid ); }
    public boolean enablePIndicate( UUID srvUuid, UUID chrtUuid ) { return mCallback.enablePIndicate( srvUuid, chrtUuid ); }

    public void error( int status, String extra )
    {
        switch ( status ) {
            case BluetoothGatt.GATT_INVALID_ATTRIBUTE_LENGTH:
                TDLog.Error("DISTOX-BLE COMM: invalid attr length " + extra );
                break;
            case BluetoothGatt.GATT_WRITE_NOT_PERMITTED:
                TDLog.Error("DISTOX-BLE COMM: write not permitted " + extra );
                break;
            case BluetoothGatt.GATT_READ_NOT_PERMITTED:
                TDLog.Error("DISTOX-BLE COMM: read not permitted " + extra );
                break;
            case BluetoothGatt.GATT_INSUFFICIENT_ENCRYPTION:
                TDLog.Error("DISTOX-BLE COMM: insufficient encrypt " + extra );
                break;
            case BluetoothGatt.GATT_INSUFFICIENT_AUTHENTICATION:
                TDLog.Error("DISTOX-BLE COMM: insufficient auth " + extra );
                break;
            case BleCallback.CONNECTION_TIMEOUT:
            case BleCallback.CONNECTION_133: // unfortunately this happens
                // TDLog.v( "BRIC comm: connection timeout or 133");
                // notifyStatus( ConnectionState.CONN_WAITING );
                reconnectDevice();
                break;
            default:
                TDLog.Error("DISTOX-BLE comm ***** ERROR " + status + ": reconnecting ...");
                reconnectDevice();
        }
        clearPending();
    }

    // try to recover from an error ...
    private void reconnectDevice()
    {
        mOps.clear();
        // mPendingCommands = 0; // FIXME COMPOSITE_COMMANDS
        clearPending();
        mCallback.closeGatt();
        if ( mReconnect ) {
            TDLog.v( "DISTOX-BLE comm ***** reconnect yes Device = [4a] status WAITING" );
            notifyStatus( ConnectionState.CONN_WAITING );
            enqueueOp( new BleOpConnect( mContext, this, mRemoteBtDevice ) ); // exec connectGatt()
            doNextOp();
            mBTConnected = true;
        } else {
            TDLog.v( "DISTOX-BLE comm ***** reconnect no Device = [4b] status DISCONNECTED" );
            notifyStatus( ConnectionState.CONN_DISCONNECTED );
        }
    }

    public void failure( int status, String extra )
    {
        // notifyStatus( ConnectionState.CONN_DISCONNECTED ); // this will be called by disconnected
        clearPending();
        // TDLog.v( "BRIC comm Failure: disconnecting ...");
        closeDevice();
    }

    public void notifyStatus( int status )
    {
        mApp.notifyStatus( status );
    }

    public boolean enlistWrite( UUID srvUuid, UUID chrtUuid, byte[] bytes )
    {
        BluetoothGattCharacteristic chrt = mCallback.getWriteChrt( srvUuid, chrtUuid );
        if ( chrt == null ) {
            TDLog.Error("DISTOXBLE comm enlist write: null write chrt");
            return false;
        }
        //Chrt.getPermission() always returns 0, I don't know why. Siwei Tian deleted
        /*if ( ! BleUtils.isChrtWrite( chrt ) ) {
            TDLog.Error("DISTOXBLE comm enlist write: cannot write chrt");
            return false;
        }*/
        // TDLog.v( "BRIC comm: enlist chrt write " + chrtUuid.toString() );
        enqueueOp( new BleOpChrtWrite( mContext, this, srvUuid, chrtUuid, bytes ) );
        doNextOp();
        //wait 100ms to let the MCU to receive correct frame, Siwei Tian added
        try {
            // TDLog.v( "View surface: drawing thread sleeps ..." );
            Thread.sleep(700);
        } catch ( InterruptedException e ) {
            return true;
        }
        return true;
    }

    public void WriteGetInfoCMD()
    {
        byte[] cmd = new byte[3];
        cmd[0] = 0x38; cmd[1] = 0x00; cmd[2] = (byte)0xE0;
        enlistWrite(DistoXBLEConst.DISTOXBLE_SERVICE_UUID,DistoXBLEConst.DISTOXBLE_CHRT_WRITE_UUID,cmd);
        cmd[0] = 0x38; cmd[1] = 0x04; cmd[2] = (byte)0xE0;
        enlistWrite(DistoXBLEConst.DISTOXBLE_SERVICE_UUID,DistoXBLEConst.DISTOXBLE_CHRT_WRITE_UUID,cmd);
    }

    public void registerInfo( DistoXBLEInfoDialog info ) { mDistoXBLEInfoDialog = info; }

}
